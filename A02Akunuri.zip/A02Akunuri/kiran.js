function calPrice(){
    a=document.getElementById("brgrQty").value;
    b=document.getElementById("drnkQty").value;
    c=document.getElementById("frysQty").value;
    if(a>30 || b>30 || c>30){
       window.alert("Quatity should be lest or equal to 30");
    }
    else{
        x=mul(a,50);
        y=mul(b,25);
        z=mul(c,20);
        op=add(x,y,z);
        $("#demo").html("TOTAL BILL AMOUNT= $"+op);
    }   
    function value(){
        window.alert ("This is a warning message!");
    }
};

function chkOut(){
    alert(document.getElementById("demo").innerHTML);
}


function mul(f,s){
    if(!isNaN(f) && !isNaN(s))
		return f*s;
	else
		throw Error("only numbers are allowed");
}
function add(p,q,r){
    return p+q+r;
}

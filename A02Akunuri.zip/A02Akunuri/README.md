My name is hari Kiran.
I have created this web page.
 This page calculates the quantity of items you want and 
 will give you the total calculated price.
 The total price will be displayed on the Screen.
 We have written a JS file for this.